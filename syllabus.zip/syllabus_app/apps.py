from django.apps import AppConfig


class SyllabusAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'syllabus_app'
